package com.springrest.Backend_Real;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendRealApplicationTests {

	@Test
	void contextLoads() {
	}

}
