package com.springrest.Backend_Real.Services;

import com.springrest.Backend_Real.Entities.Course;
import com.springrest.Backend_Real.dao.CourseDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CourseServiceImpl implements CourseService {

    @Autowired
    private CourseDao courseDao;


    // method to return all the courses .
    @Override
    public List<Course> getCourses() {
        return courseDao.findAll();
    }

    //  return course by given id .
    @Override
    public Course getCourse(long courseId)
    {

        Optional<Course> courseOptional = courseDao.findById(courseId);
        if (courseOptional.isPresent()) {
            Course course = courseOptional.get();
            return course;
        } else {
            return null;
        }
    }

    // add courses to db .
    @Override
    public Course addCourse(Course course)
    {
        courseDao.save(course);
        return course;
    }

    // update the course .
    @Override
    public Course updateCourse(Course course)
    {
        courseDao.save(course);
        return course;
    }

    // delete the course with given id.
    @Override
    public Course deleteCourse(Long courseId)
    {
        Optional<Course> optionalCourse = courseDao.findById(courseId);
        if (optionalCourse.isPresent()) {
            Course course = optionalCourse.get();
            courseDao.delete(course);
            return course;
        } else {
            return null;
        }

    }
}


