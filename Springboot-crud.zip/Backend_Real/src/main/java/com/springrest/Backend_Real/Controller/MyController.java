package com.springrest.Backend_Real.Controller;
import com.springrest.Backend_Real.Entities.Course;
import com.springrest.Backend_Real.Services.CourseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

// this annotation is used to told that this file will act as controller .
@RestController
public class MyController {

        // This will Create an object of CourseService and allow us to use its methods .
        @Autowired
        CourseService courseService ;


        // get all courses .
        @GetMapping("/courses")
        public List<Course> getCourses()
        {
                return this.courseService.getCourses();
        }

        // to get course by given id.
        @GetMapping("/courses/{courseID}")
        public Course getCourse(@PathVariable String courseId)
        {
                return this.courseService.getCourse(Long.parseLong(courseId));
        }

        // to add a new course .
        @PostMapping("/courses")
        public Course addCourse(@RequestBody Course course){
                return this.courseService.addCourse(course);
        }

        //  if there's already a course present with this id it will update that otherwise add a new one with this id .'
        @PutMapping("/courses")
        public Course updateCourse(@RequestBody Course course){
                return this.courseService.updateCourse(course);
        }

        // to delete a course by course id .Delete the course with given id .
        @DeleteMapping("/courses/{courseId}")
        public ResponseEntity<HttpStatus> deletCourse(@PathVariable String courseId){
                try{
                        this.courseService.deleteCourse(Long.parseLong(courseId));
                        return new ResponseEntity<>(HttpStatus.OK);
                }catch (Exception e){
                        return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
                }
        }
}
