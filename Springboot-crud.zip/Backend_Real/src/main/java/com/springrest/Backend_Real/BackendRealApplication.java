package com.springrest.Backend_Real;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendRealApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendRealApplication.class, args);
	}

}
