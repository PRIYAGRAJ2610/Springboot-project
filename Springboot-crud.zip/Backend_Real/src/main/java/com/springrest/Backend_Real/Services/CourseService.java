package com.springrest.Backend_Real.Services;

import com.springrest.Backend_Real.Entities.Course;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Service;

import java.util.List;
@Configuration
@ComponentScan(basePackages = {"com.springrest.Backend_Real"})

@Service
public interface CourseService {
    public List<Course> getCourses();
    public Course getCourse(long courseId);
    public Course addCourse(Course course);
    public Course updateCourse(Course course);
    public Course deleteCourse(Long courseId);


}
